from datetime import datetime
import random
import os
from pathlib import Path
from flask import Flask, session
from flask import request
from flask import render_template, send_from_directory, redirect, render_template_string
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
root_path = Path(app.root_path)
app.secret_key = os.environ['SECRET_KEY']
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ['DB_PATH']
db = SQLAlchemy(app)


class GuestBookEntry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    title = db.Column(db.String(120), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.now)
    content = db.Column(db.String(120), nullable=True)

    def __repr__(self):
        return '<GuestBookEntry %s:%s:%s>' % (self.id, self.username, self.title)


diaries = [
    ('일기장 완성!', '2018/10/20', 'myfinalwebsite.txt'),
    ('사이트 관리', '2018/11/05', 'update.txt'),
    ('취약한 플라스크', '2018/11/09', 'weakflask.txt'),
]


def give_session():
    guest_usernames = [
        'Steve Jobs', 'Steve Wozniak', 'Bill Gates', 'Tim Cook',
        'Elon Musk', 'Guido van Rossum', 'Larry Wall', 'Linus Torvalds',
    ]
    session['username'] = random.choice(guest_usernames)
    session['guest'] = 'Y'


@app.route('/')
def index():
    if 'username' not in session:
        give_session()

    return render_template('search.html', all_diaries=diaries)


@app.route('/search')
def search():

    title = request.args.get('title', None)
    if not title:
        return redirect('/')

    results = []
    for t in diaries:
        if title in t[0]:
            results.append(t)

    return render_template('search_result.html', results=results, search_query=title)


@app.route('/diary', methods=['GET'])
def diary():

    path = request.args.get('path', None)
    if not path:
        return redirect('/')

    if '/' in path:
        return "NO HACK!!!   " * 100

    if 'flag' in path.lower():
        return "GO AWAY HACKER!"

    diary_path = root_path / 'diaries' / path
    if not diary_path.is_file():
        return redirect('/')

    diary_data = diary_path.read_text(encoding='utf=8')
    return render_template('diary.html', text=diary_data.split('\n'))


@app.route('/favicon.ico')
def favicon():
    return send_from_directory(str(root_path / 'static/images'),
                               'favicon.ico', mimetype='image/vnd.microsoft.icon')


@app.route('/download',  methods=['GET'])
def download():
    if 'username' not in session:
        give_session()

    path = request.args.get('path', None)

    p = Path(path)
    return send_from_directory(str(root_path / 'diaries' / p.parent), p.name, as_attachment=True)


@app.route('/guestbook', methods=['GET'])
def guestbook():
    if 'username' not in session:
        give_session()

    entries = GuestBookEntry.query.order_by(GuestBookEntry.date.desc()).all()
    _entries = map(lambda x: [x.id, x.title, x.username, x.date.date()], entries)
    return render_template('guestbook.html', all_guestbook=_entries)


@app.route('/guestbook/read', methods=['GET'])
def guestbook_read():
    if 'username' not in session:
        give_session()

    book_id = request.args.get('id', None)

    entry = GuestBookEntry.query.filter_by(id=book_id).all()
    if not entry:
        return "Invalid ID"

    if entry[0].username != session['username']:
        return "You are not %s!" % entry[0].username

    return render_template('guestbook_entry.html',
        text=entry[0].content, title=entry[0].title, username=entry[0].username, date=entry[0].date)

@app.route('/guestbook/write', methods=['POST'])
def guestbook_write():
    if 'username' not in session:
        give_session()

    title = request.form.get('title', None)
    if title is None:
        return "title is empty"

    content = request.form.get('content', None)
    if content is None:
        return "content is empty"

    username = session['username']

    if username == 'siha':
        return "I am not a guest!"

    db.session.add(GuestBookEntry(username=username, title=title, content=content))
    db.session.commit()

    # remove old guestbook
    query = GuestBookEntry.query.filter_by(username=username).order_by(GuestBookEntry.date)
    if query.count() >= 5:
        db.session.delete(query.all()[0])
        db.session.commit()

    return redirect('/guestbook')

if __name__ == '__main__':
    app.run()
